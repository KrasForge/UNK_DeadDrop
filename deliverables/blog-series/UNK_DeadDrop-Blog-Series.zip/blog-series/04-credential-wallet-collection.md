---
title: "Inside the Collector: Browser Credentials and Wallet Files"
description: "How the collector defeats Chrome's App-Bound Encryption, sweeps the user's folders for wallet material and recovery files, and what limits its reach."
date: "2026-11-26"
author: "Ilja Krasnjanski"
canonical: "https://krasforge.github.io/UNK_DeadDrop/articles/04-credential-wallet-collection/"
kicker: "UNK_DeadDrop · Part 4"
tags:
  - "UNK_DeadDrop"
  - "infostealer"
  - "credentials"
  - "crypto wallets"
og_image_alt: "Inside the Collector: Browser Credentials and Wallet Files"
---


Following the collection code took me beyond browser passwords; its third upload variant takes every text, image and key file in the user's main and development folders whatever it is called, then searches further for files named after seeds, recovery material, credentials and tokens, while another selector includes encrypted KeePass databases, and the source sets explicit traversal budgets and quietly skips directories it cannot read. These conclusions come from the recovered scripts and the limits recorded in [E05](../preprint/evidence/E05.pdf) and [E17](../preprint/evidence/E17.pdf), together with the six macOS and Linux builds fetched on 12 November. Access permissions, traversal limits and file encryption constrain what it can recover.

## Browser databases and saved credentials

The Windows collection path splits across a Node agent, a coordinator and a Python browser-decryption component. Copying a browser database is one step. Recovering its encryption material and extracting usable credentials is another, and MITRE ATT&CK classifies this activity as [Credentials from Web Browsers (T1555.003)](https://attack.mitre.org/techniques/T1555/003/).

The Python source handles DPAPI-related key recovery and a complete bypass of the [App-Bound Encryption](https://security.googleblog.com/2024/07/improving-security-of-chrome-cookies-on.html) that Chrome has used on Windows since version 127, unwrapping the browser's key through its COM elevation service for Chrome, Edge and Brave and falling back to the legacy path where the protection is absent. It is built to survive browser updates, carrying identifiers for two generations of the elevation interface and a second invocation path that avoids calling the decrypt method by name, and the newest stage-three build I hold adds thirty-six functions to the July build's 304, covering master-key derivation, extraction of keys from browser memory, decryption under the system account and copying of SQLite databases with their sidecar files. An advisory that says only that this malware steals saved passwords leads defenders to assume, wrongly, that an up-to-date Chrome protects them.

The bypass has to satisfy the browser's check on the calling binary's path, which explains the pipeline's elevation attempts and one placement that is as useful to a defender as the bypass itself: the chain plants an embedded Python interpreter and a stock cryptography library inside Chrome's own program folder and leaves a standalone-agent log behind. Python site-packages under Chrome's installation directory are hard to explain innocently, but the interpreter and library are unmodified official builds whose hashes match every legitimate copy, so the malicious content is confined to the scripts beside them and a hunt for a trojanised runtime looks in the wrong place.

A copied `Login Data` file is not a set of plaintext passwords, and an elevated process does not prove browser decryption succeeded (the investigation found no endpoint telemetry showing what the attempts yielded). On macOS and Linux the Go agents carry the same capability in two operator packages that do not exist in the public Overlord code, `companywallet` and `browserlogin` (242 and 106 compiled functions in the November macOS builds), with Chromium master-key derivation, Safari keychain export and Firefox key-store decryption, and to obtain what they cannot read silently they phish the login password with an AppleScript dialog on macOS and KDE or GTK dialogs on Linux. Wallet selectors extend the scope beyond browser stores: the operator's list holds thirty-five browser wallet-extension identifiers, among them MetaMask, Phantom, Backpack, Solflare, TronLink and Enkrypt. Part 8 examines corresponding mnemonic and ColdKey fields in the administration frontend.

![A selected file is only the first step](assets/04-collection.png)

*Figure 1. Filename selection, file access, decryption and upload form separate stages of collection.*

### Phase 3 sweeps the user's folders

The large JavaScript collector accepts `main`, `pass` and `phase3` upload variants, and the `phase3` branch runs three searches in turn. The first takes fixed developer-credential locations, among them the SSH, GnuPG, Ethereum and cloud-provider configuration directories and the shell histories, together with environment files in the home directory and, on each data drive, environment and configuration files under any name. The second walks the desktop, documents and downloads folders, their OneDrive copies on Windows and the development folders (twelve of them on Windows), to a depth of 7 and up to 1,500 files, and takes every text, JSON, CSV, property-list, environment, image and key file of at most 2 MiB whatever its name. The third applies the same rule to a depth of 5 and up to 2,000 files, over the same folders on Windows and macOS and over the whole home directory on Linux, and adds credential-named files of further types such as Markdown, notes, logs and word-processor documents. The recorded name expression includes:

```text
key / private / wallet / phrase / passphrase
seed / mnemonic / secret / credential
password / backup / recovery / keystore
API key / token
```

I first read this phase as a lexical filename search, and that understated it. In the main and development folders a recovery note saved as a plain-text file or a screenshot is taken whatever it is called, as is one within five levels of a Linux home directory, so renaming a file is no protection there; the name pattern only decides on Windows drives without a Users folder and on macOS data volumes, where a file must carry a telling name unless it is a key-class file or an environment file. The pattern is still the clearest statement of intent in the sample set, because alongside keys and passwords it names seeds, mnemonics, passphrases, recovery data and keystores: the target is cryptocurrency recovery material wherever a user has saved it, and an advisory that describes a developer-secrets sweep understates it.

The search also runs within explicit budgets, which in the inspected source default to:

- 8 minutes for the whole phase;
- 2 minutes for each root directory;
- 15 seconds for any single directory listing, after which the directory is skipped;
- 2,500 directories visited per walk;
- the per-search depth and file limits above, with a bounded fallback walk at depth 6 and 500 files.

Environment variables can override the first four defaults. The skip list excludes dependency, system, cache and temporary directories and cloud-drive mount points, anything slow, noisy or likely to prompt, while on macOS a helper probes nine protected top-level directories under the home folder (Desktop, Documents, Downloads, Movies, Music, Pictures, Public, iCloud Drive and CloudStorage) and caches the result for the run, and a failure or timeout makes the walker skip the directory:

```text
Is this a protected top-level directory on macOS?
    No  -> continue normal traversal
    Yes -> probe readability
              readable -> continue
              failure or timeout -> skip
```

The intended effect is that no privacy dialog appears: where the process already holds the rights it takes the data, and where it does not it moves on quietly. Prompt behavior still depends on the macOS version and on what the user had already granted. The reviewed code avoids triggering consent prompts. I found no TCC bypass.

### `.kdbx` appears in the generic file selector

Two of the larger JavaScript payloads include `.kdbx` in a generic set of private-key extensions:

```javascript
const KEY_EXTENSIONS = new Set([
  ".key", ".pem", ".asc", ".pfx",
  ".p12", ".ppk", ".gpg", ".kdbx"
]);
```

This selector can collect an encrypted KeePass database without a dedicated KeePass module, from the main and development folders and, because KeePass files belong to the key class, from a data drive under any name. I found no KDBX parser or code to recover the master password, and no artifacts of other commercial password managers in any build, so the collector takes the encrypted file as it is and any cracking would happen on the operator's side. For a victim, the accurate statement is that the database has left the machine and that its contents are at risk to the extent that its passphrase is weak.

## Uploads use 2 MiB chunks, disable certificate checks and never stop

For selected files, the transfer code uses a default 2 MiB chunk size with up to five attempts per chunk, waiting 2, 4, 6 and 8 seconds between them, and a chunk that fails all five sends the whole archive attempt into an upload loop that retries indefinitely, waiting the attempt number times a five-second base delay, capped at 120 seconds. The code's own comment says the standalone run does not exit until the uploads complete, and skipping certificate validation is hard-coded on every HTTPS upload, so the implant would hand its data to any interceptor on the path. Disconnecting the network therefore does not protect a victim, because the process persists and keeps trying; the right step is to stop the process and remove its persistence.

The Go agent carries the Overlord module path, WebAssembly runtime and transport features alongside a pure-Go SQLite driver that the framework itself does not have and the operators added to read browser login databases, plus wallet and browser markers, and the [framework analysis](12-framework-and-collection-boundary.md) examines these components and the limits of the available upstream comparison. The same company-wallet stealer, with the same chunked upload path, sits behind the AI- and deepfake-verification lure pages of [Part 1](01-clickfix-clipboard-manipulation.md), so that theme is another delivery skin for one backend. The companion's [wallet-agent YARA rule](https://github.com/KrasForge/unk-scanner/blob/main/rules/yara/deaddrop_wallet_agent.yar) combines framework and environment markers with wallet-related strings, while its [stage-three collector rule](https://github.com/KrasForge/unk-scanner/blob/main/rules/yara/deaddrop_stage3_collector.yar) targets the recovered source. These rules identify file contents. Execution and completed uploads need host or server records.

## No victim-side upload inventory was recovered

Scoping an incident starts with the component that ran and the phase it reached. File permissions then bound its reach. Where phase three ran, a responder should assume that KeePass databases, the text files and screenshots of the user's main folders and any recovery-phrase files elsewhere whose names match the sweep have left the machine, and that every browser-stored credential needs rotation whatever the Chrome version. The recovered source contains neither a victim-side inventory nor completed-upload records, and an upload address read from a build is only where that build was configured to send data, because the agents resolve their server through the dead drop at run time.

The [screen-capture components](05-screen-capture-analysis.md) extend potential exposure to information displayed on the desktop.

```text
Upload variants: main, pass, phase3
Configuration: GUS_UPLOAD_CHUNK_SIZE, GUS_KEEP_AGENT_STATE
Large JavaScript payload SHA-256:
694626bed2df1f0d0026a3f7ead7692b44c7e73041cdd799b79a025335533cdc
```
